import React, { Component } from 'react';
class Daubt extends Component {
    constructor(props) {
      super(props);
      this.state = { 
      }
     }

  
render() {   
 
    return(  
      <React.Fragment>
          Welcome to Daubt page.
     </React.Fragment>
          );
        }
    }

export default Daubt;