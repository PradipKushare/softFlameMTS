import React, { Component } from 'react';

class StudyMaterial extends Component {
    constructor(props) {
      super(props);
      this.state = { 
      }
     }

  
render() {   
 
    return(  
      <React.Fragment>
          Welcome to StudyMaterial page.
     </React.Fragment>
          );
        }
    }

export default StudyMaterial;