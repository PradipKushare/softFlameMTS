import { combineReducers } from 'redux'
import save_profile from './save_profile';
import save_question_list from './save_question_list';

export default combineReducers({save_profile,save_question_list});


